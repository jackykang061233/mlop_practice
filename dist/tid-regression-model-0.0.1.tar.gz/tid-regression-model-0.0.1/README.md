This is mlop practice for the udemy course
